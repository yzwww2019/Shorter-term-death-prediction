#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os,json,random
import logging, sys, argparse
from common.reader import list_all_files
from common.reader import read_single_xlsx
from imblearn.over_sampling import RandomOverSampler

import common.reader
import numpy as np
import tensorflow as tf
import pandas as pd

def get_logger(filename):
	logger = logging.getLogger('logger')
	logger.setLevel(logging.DEBUG)
	logging.basicConfig(format='%(message)s', level=logging.DEBUG)
	handler = logging.FileHandler(filename)
	handler.setLevel(logging.DEBUG)
	handler.setFormatter(logging.Formatter('%(asctime)s:%(levelname)s: %(message)s'))
	logging.getLogger().addHandler(handler)
	return logger

def data_load(x_path, label_path, mode="train"):

	filelist, labeldict = list_all_files(x_path, label_path)

	##Each file is traversed, and returned wrapped as a list of [file name, data matrix, label]

	datalist = []
	trainlist=[]
	labellist=[]
	for file in filelist:
		one_file = []
		Single_file_data = read_single_xlsx(file)
		whole_data = Single_file_data
		#The label is processed as a 0-1 encoding vector
		labeldata = label_discrete(labeldict[file])

		trainlist.append([file, whole_data])
		labellist.append([labeldata])
		pass
	ros = RandomOverSampler(random_state=0)  # Random oversampling
	x_resample, y_resample = ros.fit_resample(trainlist, labellist)

	for i in range(0,len(x_resample)):
		if y_resample[i]==0:
			datalist.append([x_resample[i][0],x_resample[i][1],[1,0]])
		else:
			datalist.append([x_resample[i][0],x_resample[i][1],[0,1]])

	return datalist
	pass

def data_load2(x_path, label_path, mode="train"):

	filelist, labeldict = list_all_files(x_path, label_path)

	##Each file is traversed, and returned wrapped as a list of [file name, data matrix, label]

	datalist = []
	for file in filelist:
		one_file = []
		Single_file_data = read_single_xlsx(file)

		whole_data = Single_file_data
		#The label is processed as a 0-1 encoding vector
		labeldata = label_discrete2(labeldict[file])
		datalist.append([file, whole_data, labeldata])

		pass

	return datalist
	pass

def label_discrete(intlabel):

	result =int(intlabel)
	return result
	pass

def label_discrete2(intlabel):

	result = [0, 0]
	result[int(intlabel)] = 1

	return result
	pass

def get_next_batch(datalist, batch_size, shuffle=False):  #批次控制

	if shuffle:
		random.shuffle(datalist)
	a=[]
	for data in datalist:
		if len(a) == batch_size:
			yield a
			a=[]
		a.append(data)
		pass
	if len(a) == batch_size:
		yield a
	pass

def squence_padding(raw_data, variabel_dim):
	rawx,rawy,rawseq = [],[],[]
	max_length = -1

	for x in raw_data:
		if len(x[1]) > max_length:
			max_length = len(x[1])
			pass
		rawy.append(x[2])
		rawseq.append(len(x[1]))
		pass
	zero_list = [0] * variabel_dim
	for x in raw_data:
		temp = x[1]
		for i in range(0, max_length - len(x[1])):
			temp = np.append(temp, [zero_list], axis=0)
			pass

		rawx.append(temp)

	return rawx, rawy, rawseq
	pass

def optimizer_adaptor(optimizer, learning_rate=0.001, adam_beta1=0.9):
	if optimizer == 'Adam':
		optim = tf.train.AdamOptimizer(learning_rate=learning_rate, beta1 = adam_beta1)
	elif optimizer == 'Adadelta':
		optim = tf.train.AdadeltaOptimizer(learning_rate=learning_rate)
	elif optimizer == 'Adagrad':
		optim = tf.train.AdagradOptimizer(learning_rate=learning_rate)
	elif optimizer == 'RMSProp':
		optim = tf.train.RMSPropOptimizer(learning_rate=learning_rate)
	elif optimizer == 'Momentum':
		optim = tf.train.MomentumOptimizer(learning_rate=learning_rate, momentum=0.9)
	elif optimizer == 'SGD':
		optim = tf.train.GradientDescentOptimizer(learning_rate=learning_rate)
	else:
		optim = tf.train.GradientDescentOptimizer(learning_rate=learning_rate)

	return optim
	pass