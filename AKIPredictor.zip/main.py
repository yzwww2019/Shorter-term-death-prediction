#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os,sys,argparse,imp,re,random,time
import numpy as np
import tensorflow as tf

from utils import get_logger
from utils import data_load
from utils import data_load2

from evaluate import print_metrics_binary
from evaluate import intervalidate_result_save
from evaluate import extervalidate_result_save

#GPU Configuration
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
config = tf.ConfigProto()
config.gpu_options.allow_growth = True
config.gpu_options.per_process_gpu_memory_fraction = 0.8

#model parameter
parser = argparse.ArgumentParser(description='')
parser.add_argument('--network', type=str, default="./models/AKIPredictor.py", help='model')
parser.add_argument('--data', type=str, default='G:/my/AKIPredictor/data/', help='data directory')
parser.add_argument('--depth', type=int, default=3000,help='the number of hidden layers')
parser.add_argument('--layer', type=int, default=2,help='the number of bidirectional LSTM')
parser.add_argument('--epoch', type=int, default=100, help='#epoch of training')
parser.add_argument('--batch_size', type=int, default=128, help='#sample of each batch')
parser.add_argument('--hidden_dim', type=int, default=16, help='#dim of hidden state')
parser.add_argument('--optimizer', type=str, default='Adam', help='Adam/Adadelta/Adagrad/RMSProp/Momentum/SGD')
parser.add_argument('--beta1', type=float, default=0.9,help='beta_1 param for Adam optimizer')
parser.add_argument('--lr', type=float, default=0.00001, help='learning rate')
parser.add_argument('--clip', type=float, default=5.0, help='gradient clipping')
parser.add_argument('--dropout', type=float, default=0.95, help='dropout keep_pro')
parser.add_argument('--shuffle', type=bool, default=True, help='shuffle training data before each epoch')
parser.add_argument('--dgh', type=bool, default=True, help='add demographic information or not (not use)')
parser.add_argument('--mode',type=str,default="train",help="train/extervalidate")
parser.add_argument('--load_state',type=str,default='',help='model checkpoint path')
args = parser.parse_args()

'''
Define the model and initialize the calculation graph
'''
assert args.network is not None
print("==> using model {}".format(args.network))
model_module = imp.load_source(os.path.basename(args.network), args.network)

'''
num_classes：the number of class
input_dim：the number of clinical variables
'''
model = model_module.Network(args, config, num_classes = 2, input_dim = 110)
model_suffix = "_dgp{}_{}".format(int(args.dgh),str(int(time.time())))
model.final_name = model.say_name() + model_suffix
print("==> model_final_name:", model.final_name)

'''
Set paths for the model, 
log_path: logging path
model_path: the path of the calculation graph of the final epoch
prediction_path: the save path of the predicted result
'''
paths = {}
modelname = model.final_name if args.load_state == '' else args.load_state
output_path = os.path.join('.',"output_save_path",modelname)
model_path = os.path.join(output_path, "checkpoints/")
result_path = os.path.join(output_path, "results")
summary_path = os.path.join(output_path, "summaries")
log_path = os.path.join(result_path, "log.txt")
paths['model_path'] = model_path
paths['summary_path'] = summary_path
model.init_model_save_path(paths)
if not os.path.exists(result_path): 
    os.makedirs(result_path)
    pass
logger = get_logger(log_path)
if args.load_state == "":
    logger.info(str(args))
    pass

'''
If the model is reloaded, read the path of the calculation graph, and the number of recent iterations
ckpt_file、global_epoch
'''
ckpt_file = None
if args.load_state != "":
    if not os.path.exists(model_path):
        raise Exception("the folder {} is not exists".format(model_path))
    ckpt_file = tf.train.latest_checkpoint(model_path)
global_epoch = 0
if not ckpt_file == None: 
    global_epoch = int(re.findall(r'\d+', ckpt_file)[-1])
print("==>At model epoch",global_epoch)

'''
Read the data and split it into derivation and internal validation cohorts
'''
derivation_data_path = os.path.join(args.data,'train/')
derivation_label_path = os.path.join(args.data,'totaltrain.csv')
derivation_data = data_load(derivation_data_path, derivation_label_path, mode='train')
random.shuffle(derivation_data)

intervalidation_data_path = os.path.join(args.data,'test/')
intervalidation_label_path = os.path.join(args.data,'totaltest.csv')
intervalidation_data = data_load2(intervalidation_data_path, intervalidation_label_path, mode='train')
random.shuffle(intervalidation_data)

'''
Read external validation cohort
'''
#extervalidation_data_path = os.path.join(args.data,'val/')
#extervalidation_label_path = os.path.join(args.data,'totalval.csv')
#extervalidation_data = data_load2(extervalidation_data_path , extervalidation_label_path, mode='train')
#random.shuffle(extervalidation_data)

'''
Enter the corresponding mode according to self.mode (train or extervalidate)
'''
if args.mode == 'train':
	print("training mode")
	saver = tf.train.Saver(tf.global_variables())
	with tf.Session(config=config) as sess:
		#if the model has checkpoint,load
		if ckpt_file == None:
			sess.run(tf.global_variables_initializer())
			pass
		else: # if exists checkpoint，load
			saver.restore(sess, ckpt_file)
		#training epoch by epoch
		model.addSummary(sess)
		min_loss = 1000
		for epoch in range(args.epoch):

			logger.info('==========================================')
			logger.info('===========training on epoch {}==========='.format(epoch+global_epoch+1))
			model.train_one_epoch(sess, derivation_data, epoch+global_epoch+1, saver, logger)

			logger.info('==> loss on derivation cohort')
			predictions,labels,losses = model.predict_one_epoch(sess, derivation_data)       #Calculate the loss of derivation cohort
			train_result = print_metrics_binary(labels, predictions, verbose=1)
			train_result['losses'] = losses
			logger.info(train_result)

			logger.info('=======================================')
			logger.info('==> loss on internal validation cohort')
			predictions,labels,losses = model.predict_one_epoch(sess, intervalidation_data)  #Calculate the loss of internal validation cohort
			intervalidation_result = print_metrics_binary(labels, predictions,verbose=1)
			intervalidation_result['losses'] = losses
			logger.info(intervalidation_result)
			intervalidate_result_save(train_result,intervalidation_result,result_path,epoch+global_epoch+1)

			if intervalidation_result['losses'] < min_loss:                                  #determine the model with the minimum loss on internal validation cohort, and then save it
				saver.save(sess, model.model_path, global_step = epoch+global_epoch+1)
				min_loss = intervalidation_result['losses']
				pass
			pass
		pass
	pass

elif args.mode == 'extervalidate':
	'''
	Read external validation cohort
	'''
	filename = []
	for item in extervalidation_data:
		filename.append(item[0])
		pass

	if ckpt_file ==None:
		raise Exception("No checkpoint model was found")
		pass

	saver = tf.train.Saver()

	with tf.Session(config=config) as sess:
		logger.info('=========== external validation ===========')
		saver.restore(sess, ckpt_file)
		predictions,labels,losses = model.predict_one_epoch(sess, extervalidation_data)  #Calculate the loss of external validation cohort

		extervalidation_result = print_metrics_binary(labels, predictions,verbose=1)
		extervalidation_result['losses'] = losses
		logger.info(extervalidation_result)
		extervalidate_result_save(predictions,labels,filename,result_path)
		pass
	pass
else:
	raise ValueError("Wrong value [{}] for parameter args.mode".format(args.mode))